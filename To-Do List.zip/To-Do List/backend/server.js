const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Database connection
mongoose.connect('mongodb://localhost:27017/todo', { useNewUrlParser: true, useUnifiedTopology: true });

// Routes
const taskRoutes = require('./routes/tasks');
app.use('/tasks', taskRoutes);

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:3000`);
});
