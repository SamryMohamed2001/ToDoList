document.addEventListener('DOMContentLoaded', function() {
  const API_URL = 'http://localhost:3000';
  const taskForm = document.getElementById('task-form');
  const taskList = document.getElementById('task-list');

  function fetchTasks() {
    fetch(`http://localhost:3000/tasks`)
      .then(response => response.json())
      .then(tasks => {
        taskList.innerHTML = '';
        tasks.forEach(task => {
          addTaskToDOM(task);
        });
      })
      .catch(error => console.error('Fetch tasks error:', error));
  }

  function addTaskToDOM(task) {
    const li = document.createElement('li');
    li.dataset.id = task._id;
    li.className = task.completed ? 'completed' : '';
    li.innerHTML = `
      <span>${task.text}</span>
      <div>
        <button class="edit">Edit</button>
        <button class="complete">${task.completed ? 'Undo' : 'Complete'}</button>
        <button class="delete">Delete</button>
      </div>
    `;
    taskList.appendChild(li);
  }

  taskForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const taskInput = document.getElementById('task-input');
    const taskText = taskInput.value.trim();
    const priority = document.getElementById('priority-input').value;
    if (taskText) {
      fetch(`http://localhost:3000/tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: taskText, priority })
      })
      .then(response => response.json())
      .then(task => {
        addTaskToDOM(task);
        taskInput.value = '';
      })
      .catch(error => console.error('Add task error:', error));
    }
  });

  taskList.addEventListener('click', function(e) {
    const li = e.target.closest('li');
    const taskId = li.dataset.id;

    if (e.target.classList.contains('edit')) {
      const newText = prompt('Edit task', li.querySelector('span').textContent);
      if (newText) {
        fetch(`http://localhost:3000/tasks/${taskId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ text: newText })
        })
        .then(response => response.json())
        .then(updatedTask => {
          li.querySelector('span').textContent = updatedTask.text;
        })
        .catch(error => console.error('Edit task error:', error));
      }
    } else if (e.target.classList.contains('complete')) {
      const completed = !li.classList.contains('completed');
      fetch(`http://localhost:3000/tasks/${taskId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ completed })
      })
      .then(response => response.json())
      .then(updatedTask => {
        li.classList.toggle('completed', updatedTask.completed);
        e.target.textContent = updatedTask.completed ? 'Undo' : 'Complete';
      })
      .catch(error => console.error('Complete task error:', error));
  } else if (e.target.classList.contains('delete')) {
    fetch(`http://localhost:3000/tasks/${taskId}`, {
      method: 'DELETE'
    })
    .then(() => {
      taskList.removeChild(li);
    })
    .catch(error => console.error('Delete task error:', error));
  }
});

// Initial fetch of tasks when the page loads
fetchTasks();

// Sortable functionality to reorder tasks
new Sortable(taskList, {
  animation: 150,
  onEnd: function(evt) {
    const items = Array.from(taskList.children);
    const order = items.map((item, index) => ({ id: item.dataset.id, order: index }));
    fetch(`http://localhost:3000/tasks/order`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(order)
    })
    .catch(error => console.error('Order tasks error:', error));
  }
});
});
